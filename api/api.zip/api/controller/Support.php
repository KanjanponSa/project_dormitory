<?php
namespace Controller;

use \Psr\Http\Message\ResponseInterface as Response;
use \Psr\Http\Message\ServerRequestInterface as Request;

class Support
{
    public function getServerTime(Request $request, Response $response, $args)
    {
        $response->getBody()->write(\json_encode(array(
            "success" => true,
            "isLogin" => $request->getAttribute('isLogin'),
            "result" => time() * 1000,
        )));
        return $response;
    }

    public function getOverdueTerm1(Request $request, Response $response, $args)
    {
        $db = new \Tools\Database();
        $query = $db->query(
            "SELECT *
            FROM (
                SELECT
                `student_data`.`dormitory_price` - `student_data`.`dormitory_paid` as `dormitory_overdue`,
                `student_data`.`electric_first_price` - `student_data`.`electric_first_paid` as `electric_first_overdue`,
                `student_data`.`water_first_price` - `student_data`.`water_first_paid` as `water_first_overdue`,
                `student_data`.`insurance_price` - `student_data`.`insurance_paid` as `insurance_overdue`,
                `student_data`.*,
                `branch`.`faculty_code`,
                `branch`.`name` as `branch_name`,
                `branch`.`name_en` as `branch_name_en`,
                `branch`.`acronym`,
                `faculty`.`name` as `faculty_name`,
                `faculty`.`name_en` as `faculty_name_en`
                FROM (
                    SELECT *
                    FROM (
                        SELECT
                        (
                            SELECT `dormitory`
                            FROM `cost_value`
                            WHERE `cost_value`.`term` = '1'
                            AND `cost_value`.`room_type` =
                                CASE WHEN
                                        SUBSTR(`room_student`.`room_number`, 2, 1) <= 7
                                    THEN '1'
                                    ELSE '2'
                                END
                        ) as `dormitory_price`,
                        (
                            SELECT `electric_first`
                            FROM `cost_value`
                            WHERE `cost_value`.`term` = '1'
                            AND `cost_value`.`room_type` =
                                CASE WHEN
                                        SUBSTR(`room_student`.`room_number`, 2, 1) <= 7
                                    THEN '1'
                                    ELSE '2'
                                END
                        ) as `electric_first_price`,
                         (
                            SELECT `water_first`
                            FROM `cost_value`
                            WHERE `cost_value`.`term` = '1'
                            AND `cost_value`.`room_type` =
                                CASE WHEN
                                        SUBSTR(`room_student`.`room_number`, 2, 1) <= 7
                                    THEN '1'
                                    ELSE '2'
                                END
                        ) as `water_first_price`,
                         (
                            SELECT `insurance`
                            FROM `cost_value`
                            WHERE `cost_value`.`term` = '1'
                            AND `cost_value`.`room_type` =
                                CASE WHEN
                                        SUBSTR(`room_student`.`room_number`, 2, 1) <= 7
                                    THEN '1'
                                    ELSE '2'
                                END
                        ) as `insurance_price`,
                        COALESCE(`cost`.`dormitory_paid`, 0 ) as `dormitory_paid`,
                        COALESCE(`cost`.`electric_first_paid`, 0 ) as `electric_first_paid`,
                        COALESCE(`cost`.`water_first_paid`, 0 ) as `water_first_paid`,
                        COALESCE(`cost`.`insurance_paid`, 0 ) as `insurance_paid`,
                        `room_student`.`std_code`,
                        `student`.`nameTitle`,
                        `student`.`fname`,
                        `student`.`lname`,
                        `student`.`phone`,
                        `room_student`.`room_number`,
                        `student`.`groupStd`,
                        `student`.`branch_code`
                        FROM (
                            SELECT * FROM (
                                SELECT
                                `studentId`,
                                SUM(`dorimitory`) as `dormitory_paid`,
                                SUM(`electric_first`) as `electric_first_paid`,
                                SUM(`water_first`) as `water_first_paid`,
                                SUM(`insurance`) as `insurance_paid`
                                FROM `student_cost`
                                WHERE `student_cost`.`term` = '1'
                                GROUP BY `studentId`
                            ) as `cost`
                        ) as `cost`
                        RIGHT JOIN `room_student`
                        ON `room_student`.`std_code` = `cost`.`studentId`
                        INNER JOIN `student`
                        ON `room_student`.`std_code` = `student`.`std_code`
                    ) as `student_data`
                    WHERE `student_data`.`dormitory_price` >= `student_data`.`dormitory_paid`
                    OR `student_data`.`electric_first_price` >= `student_data`.`electric_first_paid`
                    OR `student_data`.`water_first_price` >= `student_data`.`water_first_paid`
                    OR `student_data`.`insurance_price` >= `student_data`.`insurance_paid`
                ) as `student_data`
                LEFT JOIN `branch`
                ON `branch`.`branch_code` = `student_data`.`branch_code`
                LEFT JOIN `faculty`
                ON `branch`.`faculty_code` = `faculty`.`faculty_code`
            ) as `paid_data`"
        );

        $response->getBody()->write(\json_encode(array(
            "ip_address" => $request->getAttribute('ip_address'),
            "isLogin" => $request->getAttribute('isLogin'),
            "result" => $query,
        )));
        return $response;
    }

    public function getOverdueTerm2(Request $request, Response $response, $args)
    {
        $db = new \Tools\Database();
        $query = $db->query(
            "SELECT *
            FROM (
                SELECT
                `student_data`.`dormitory_price` - `student_data`.`dormitory_paid` as `dormitory_overdue`,
                `student_data`.`electric_first_price` - `student_data`.`electric_first_paid` as `electric_first_overdue`,
                `student_data`.`water_first_price` - `student_data`.`water_first_paid` as `water_first_overdue`,
                `student_data`.`insurance_price` - `student_data`.`insurance_paid` as `insurance_overdue`,
                `student_data`.*,
                `branch`.`faculty_code`,
                `branch`.`name` as `branch_name`,
                `branch`.`name_en` as `branch_name_en`,
                `branch`.`acronym`,
                `faculty`.`name` as `faculty_name`,
                `faculty`.`name_en` as `faculty_name_en`
                FROM (
                    SELECT *
                    FROM (
                        SELECT
                        (
                            SELECT `dormitory`
                            FROM `cost_value`
                            WHERE `cost_value`.`term` = '2'
                            AND `cost_value`.`room_type` =
                                CASE WHEN
                                        SUBSTR(`room_student`.`room_number`, 2, 1) <= 7
                                    THEN '1'
                                    ELSE '2'
                                END
                        ) as `dormitory_price`,
                        (
                            SELECT `electric_first`
                            FROM `cost_value`
                            WHERE `cost_value`.`term` = '2'
                            AND `cost_value`.`room_type` =
                                CASE WHEN
                                        SUBSTR(`room_student`.`room_number`, 2, 1) <= 7
                                    THEN '1'
                                    ELSE '2'
                                END
                        ) as `electric_first_price`,
                         (
                            SELECT `water_first`
                            FROM `cost_value`
                            WHERE `cost_value`.`term` = '2'
                            AND `cost_value`.`room_type` =
                                CASE WHEN
                                        SUBSTR(`room_student`.`room_number`, 2, 1) <= 7
                                    THEN '1'
                                    ELSE '2'
                                END
                        ) as `water_first_price`,
                         (
                            SELECT `insurance`
                            FROM `cost_value`
                            WHERE `cost_value`.`term` = '2'
                            AND `cost_value`.`room_type` =
                                CASE WHEN
                                        SUBSTR(`room_student`.`room_number`, 2, 1) <= 7
                                    THEN '1'
                                    ELSE '2'
                                END
                        ) as `insurance_price`,
                        COALESCE(`cost`.`dormitory_paid`, 0 ) as `dormitory_paid`,
                        COALESCE(`cost`.`electric_first_paid`, 0 ) as `electric_first_paid`,
                        COALESCE(`cost`.`water_first_paid`, 0 ) as `water_first_paid`,
                        COALESCE(`cost`.`insurance_paid`, 0 ) as `insurance_paid`,
                        `room_student`.`std_code`,
                        `student`.`nameTitle`,
                        `student`.`fname`,
                        `student`.`lname`,
                        `student`.`phone`,
                        `room_student`.`room_number`,
                        `student`.`groupStd`,
                        `student`.`branch_code`
                        FROM (
                            SELECT * FROM (
                                SELECT
                                `studentId`,
                                SUM(`dorimitory`) as `dormitory_paid`,
                                SUM(`electric_first`) as `electric_first_paid`,
                                SUM(`water_first`) as `water_first_paid`,
                                SUM(`insurance`) as `insurance_paid`
                                FROM `student_cost`
                                WHERE `student_cost`.`term` = '2'
                                GROUP BY `studentId`
                            ) as `cost`
                        ) as `cost`
                        RIGHT JOIN `room_student`
                        ON `room_student`.`std_code` = `cost`.`studentId`
                        INNER JOIN `student`
                        ON `room_student`.`std_code` = `student`.`std_code`
                    ) as `student_data`
                    WHERE `student_data`.`dormitory_price` >= `student_data`.`dormitory_paid`
                    OR `student_data`.`electric_first_price` >= `student_data`.`electric_first_paid`
                    OR `student_data`.`water_first_price` >= `student_data`.`water_first_paid`
                    OR `student_data`.`insurance_price` >= `student_data`.`insurance_paid`
                ) as `student_data`
                LEFT JOIN `branch`
                ON `branch`.`branch_code` = `student_data`.`branch_code`
                LEFT JOIN `faculty`
                ON `branch`.`faculty_code` = `faculty`.`faculty_code`
            ) as `paid_data`"
        );

        $response->getBody()->write(\json_encode(array(
            "ip_address" => $request->getAttribute('ip_address'),
            "isLogin" => $request->getAttribute('isLogin'),
            "result" => $query,
        )));
        return $response;
    }

    public function getRoom(Request $request, Response $response, $args)
    {

        $db = new \Tools\Database();
        $query = $db->query(
            "SELECT DISTINCT SUBSTRING(room_number, 1, 4) as room_number FROM `room` ORDER BY `room_number`"
        );
        $response->getBody()->write(\json_encode(array(
            "ip_address" => $request->getAttribute('ip_address'),
            "isLogin" => $request->getAttribute('isLogin'),
            "result" => $query,
        )));
        return $response;
    }

    public function getStudentQuestion(Request $request, Response $response, $args)
    {
        $db = new \Tools\Database();
        $query = $db->query(
            "SELECT* FROM qa_student ORDER BY create_at DESC"
        );
        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function studentQuestion(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"));
        $db = new \Tools\Database();
        $query = $db->query(
            "INSERT INTO qa_student (question, student)
            VALUES ('" . $rawdata->question . "', '" . $rawdata->student . "')"
        );
        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function adminAnswer(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"));
        $db = new \Tools\Database();
        $query = $db->query(
            "UPDATE qa_student
            SET answer='" . $rawdata->answer . "',
            admin='" . $rawdata->admin . "'
            WHERE id='" . $rawdata->id . "'"
        );
        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function getAdminType(Request $request, Response $response, $args)
    {
        $db = new \Tools\Database();
        $query = $db->query(
            "SELECT * FROM `admin_type`"
        );

        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function getAdminUsers(Request $request, Response $response, $args)
    {
        $db = new \Tools\Database();
        $query = $db->query(
            "SELECT * FROM `user`
            WHERE `user`.`type` != '0'
            AND `user`.`personalId`
            "
        );

        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function getStudentUsers(Request $request, Response $response, $args)
    {
        $db = new \Tools\Database();
        $query = $db->query(
            "SELECT * FROM `user`
            INNER JOIN `student` ON `user`.`username` = `student`.`std_code`
            WHERE `user`.`type` = '0' AND `student`.`status` = '1'"
        );

        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function addUserData(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"));
        $db = new \Tools\Database();
        $query = $db->query(
            "INSERT INTO `user`
            (`username`,
             `password`,
             `nameTitle`,
             `fname`,
             `lname`,
             `personalId`,
             `role`,
             `type`)
             VALUES
             ('" . $rawdata->username . "',
             '" . md5($rawdata->password) . "',
             '" . $rawdata->nameTitle . "',
             '" . $rawdata->fname . "',
             '" . $rawdata->lname . "',
             '" . $rawdata->personalId . "',
             '" . $rawdata->role . "',
             '" . $rawdata->type . "')"
        );

        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function updateUserData(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"));
        $db = new \Tools\Database();
        $query = $db->query(
            "UPDATE `user` SET
            `nameTitle` = '" . $rawdata->nameTitle . "',
            `fname` = '" . $rawdata->fname . "',
            `lname` = '" . $rawdata->lname . "',
            `personalId` = '" . $rawdata->personalId . "',
            `type` = '" . $rawdata->type . "'
            WHERE `user`.`username` = '" . $rawdata->username . "'"
        );

        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function updateUserDataWithPassword(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"));
        $db = new \Tools\Database();
        $query = $db->query(
            "UPDATE `user` SET
            `password` = '" . md5($rawdata->password) . "',
            `nameTitle` = '" . $rawdata->nameTitle . "',
            `fname` = '" . $rawdata->fname . "',
            `lname` = '" . $rawdata->lname . "',
            `personalId` = '" . $rawdata->personalId . "',
            `type` = '" . $rawdata->type . "'
            WHERE `user`.`username` = '" . $rawdata->username . "'"
        );

        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function updateStudentData(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"));
        $db = new \Tools\Database();
        $query = $db->query(
            "UPDATE `student` SET
            `nameTitle` = '" . $rawdata->nameTitle . "',
            `fname` = '" . $rawdata->fname . "',
            `lname` = '" . $rawdata->lname . "'
            WHERE `student`.`std_code` = '" . $rawdata->username . "'"
        );

        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function updateStudentPassword(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"));
        $db = new \Tools\Database();
        $output = null;
        $updatePassword = $db->query(
            "UPDATE `user` SET
            `password` = '" . md5($rawdata->password) . "'
            WHERE `user`.`username` = '" . $rawdata->username . "'"
        );
        $updateData = $db->query(
            "UPDATE `student` SET
            `nameTitle` = '" . $rawdata->nameTitle . "',
            `fname` = '" . $rawdata->fname . "',
            `lname` = '" . $rawdata->lname . "',
            `type` = '" . $rawdata->type . "'
            WHERE `student`.`std_code ` = '" . $rawdata->username . "'"
        );

        $output = array(
            "updatePassword" => $updatePassword,
            "updateData" => $updateData,
        );

        $response->getBody()->write(\json_encode($output));
        return $response;
    }

    public function getStudentInRoom(Request $request, Response $response, $args)
    {
        $db = new \Tools\Database();
        $query = $db->query(
            "SELECT
            COUNT(`std_code`) as `total`,
            GROUP_CONCAT(`std_code`) as `std_code`,
            SUBSTR(`room_number`, 1, 4) as `room_number`
            FROM `room_student` WHERE `room_number` LIKE '" . $args['room_number'] . "%'"
        );

        $response->getBody()->write(\json_encode($query));
        return $response;
    }
}
